# Slide2text > 2025-05-16 9:18am
https://universe.roboflow.com/4bah/slide2text-peivr

Provided by a Roboflow user
License: CC BY 4.0

